//category add
$("#category").click(function (e) {
        e.preventDefault();
        var url =  $(this).attr('href');
        $("#my-modal").modal("show");
        sendData(url);

});

$('body').on('click', '.update-pl-category', function (event){
        event.preventDefault();
        var url =  $(this).attr('href');
        $("#my-modal").modal("show");
        sendData(url);
});

$('body').on('click', '.view-pl-category', function (event){
        event.preventDefault();
        var url =  $(this).attr('href');
        $("#my-modal").modal("show");
        sendDataView(url);
});

//tuman add
$("#modalOne").click(function (e) {
        e.preventDefault();
        var url =  $(this).attr('href');
        $("#my-modal").modal("show");
        sendData(url);

});
$('body').on('click', '.update-pl', function (event){
        event.preventDefault();
        var url =  $(this).attr('href');
        $("#my-modal").modal("show");
        sendData(url);
});

$('body').on('click', '.view-pl', function (event){
        event.preventDefault();
        var url =  $(this).attr('href');
        $("#my-modal").modal("show");
        sendDataView(url);
});

$('body').on('click', '.update-pl-user', function (event){
        event.preventDefault();
        var url =  $(this).attr('href');
        $("#my-modal").modal("show");
        sendData(url);

});

$('body').on('click', '.view-pl-user', function (event){
        event.preventDefault();
        var url =  $(this).attr('href');
        $("#my-modal").modal("show");
        sendDataView(url);
});


function sendData(_url, formData=null) {
        $.ajax({
                url: _url,
                type: "POST",
                dataType: "json",
                data: formData,
                success: function (mal) {
                        if (mal.status == false)
                        {

                                $("#my-modal").modal('show').find("#modal-content").html(mal.content);
                                $("#modal-save").click(function (e) {
                                        var form = $('#my-form').serialize();
                                        sendData(_url, form);
                                        return false;
                                });

                                return false;
                        }
                        else{
                                $.pjax.reload({container:'#employe'});
                                $("#my-modal").modal('hide')
                        }
                },
                error: function (exception) {
                        $("#modal-content").html("<h4>Xatolik yuz</h4>");
                }
        });
}

function sendDataView(_url){
        $.ajax({
                url: _url,
                type: "POST",
                dataType: "json",
                // data: formData,
                success: function (mal) {
                        $("#my-modal").modal('show').find("#modal-content").html(mal);
                },
                error: function (exception) {
                        $("#modal-content").html("<h4>Xatolik yuz</h4>");
                }
        });
}